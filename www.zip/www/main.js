(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _redirect_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./redirect.component */ 8064);




const routes = [
    {
        path: '',
        redirectTo: 'post',
        pathMatch: 'full'
    },
    {
        path: 'folder/:id',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_folder_folder_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./folder/folder.module */ 3412)).then(m => m.FolderPageModule)
    },
    {
        path: 'post',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_post_post_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./post/post.module */ 2076)).then(m => m.PostPageModule)
    },
    {
        path: 'ft',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_ft_ft_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./ft/ft.module */ 1117)).then(m => m.FtPageModule)
    },
    {
        path: 'cari',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_cari_cari_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./cari/cari.module */ 9046)).then(m => m.CariPageModule)
    },
    {
        path: 'fft/:kw',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_fft_fft_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./fft/fft.module */ 6467)).then(m => m.FftPageModule)
    },
    {
        path: 'favorite',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_favorite_favorite_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./favorite/favorite.module */ 6042)).then(m => m.FavoritePageModule)
    },
    {
        path: 'history',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_history_history_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./history/history.module */ 2486)).then(m => m.HistoryPageModule)
    },
    {
        path: 'download',
        component: _redirect_component__WEBPACK_IMPORTED_MODULE_0__.RedirectComponent,
        pathMatch: 'full'
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_3__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 5041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 3383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 9259);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _services_post_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/post.service */ 9166);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);









let AppComponent = class AppComponent {
    constructor(postServices, routes, route, menuCtrl, plt, platform) {
        this.postServices = postServices;
        this.routes = routes;
        this.route = route;
        this.menuCtrl = menuCtrl;
        this.plt = plt;
        this.platform = platform;
        this.appPages = [
            { title: 'Daftar Update', url: '/post', icon: 'list' },
            { title: 'List Fan Translation', url: '/ft', icon: 'apps' },
            { title: 'Favorites', url: '/favorite', icon: 'heart' },
            { title: 'History', url: '/history', icon: 'time' },
            // { title: 'Download Aplikasi', url: '/download', string:'apk', icon: 'download' },
        ];
        this.labels = ['BerkasNovel App', 'Ver 5.0'];
        this.page = 1;
        this.routes.routeReuseStrategy.shouldReuseRoute = () => false;
    }
    ngOnInit() {
        this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormGroup({
            kw: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__.FormControl(null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__.Validators.required])
        });
    }
    CariNovel() {
        this.kw = this.form.value.kw;
        console.log(this.kw);
        this.routes.navigateByUrl('/', { skipLocationChange: true }).then(() => this.routes.navigate(['/cari']));
        this.menuCtrl.toggle();
    }
};
AppComponent.ctorParameters = () => [
    { type: _services_post_service__WEBPACK_IMPORTED_MODULE_2__.PostsService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.ActivatedRoute },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.Platform },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.Platform }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-root',
        template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 6747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/platform-browser */ 318);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _detail_detail_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail/detail.component */ 9337);
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ 9128);
/* harmony import */ var _fft_fft_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./fft/fft.page */ 7848);
/* harmony import */ var _ft_ft_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ft/ft.page */ 9431);
/* harmony import */ var _awesome_cordova_plugins_background_mode_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @awesome-cordova-plugins/background-mode/ngx */ 4416);
/* harmony import */ var _post_post_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./post/post.page */ 8461);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ 190);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ 5041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ 158);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/storage-angular */ 7566);

















let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__.AppComponent, _detail_detail_component__WEBPACK_IMPORTED_MODULE_0__.DetailComponent],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__.BrowserModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicModule.forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__.AppRoutingModule, _angular_common_http__WEBPACK_IMPORTED_MODULE_13__.HttpClientModule, _angular_forms__WEBPACK_IMPORTED_MODULE_14__.ReactiveFormsModule, _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_15__.IonicStorageModule.forRoot()],
        providers: [{ provide: _angular_router__WEBPACK_IMPORTED_MODULE_16__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_12__.IonicRouteStrategy }, _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_1__.NativeStorage, _fft_fft_page__WEBPACK_IMPORTED_MODULE_2__.FftPage, _ft_ft_page__WEBPACK_IMPORTED_MODULE_3__.FtPage, _awesome_cordova_plugins_background_mode_ngx__WEBPACK_IMPORTED_MODULE_4__.BackgroundMode, _post_post_page__WEBPACK_IMPORTED_MODULE_5__.PostPage, _ionic_storage__WEBPACK_IMPORTED_MODULE_6__.Storage],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 9337:
/*!********************************************!*\
  !*** ./src/app/detail/detail.component.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailComponent": () => (/* binding */ DetailComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail.component.html?ngResource */ 5554);
/* harmony import */ var _detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail.component.scss?ngResource */ 1314);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ 318);
/* harmony import */ var _services_post_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/post.service */ 9166);








let DetailComponent = class DetailComponent {
    constructor(modalCtrl, domSanit, postServices, loadingCtrl, plt) {
        this.modalCtrl = modalCtrl;
        this.domSanit = domSanit;
        this.postServices = postServices;
        this.loadingCtrl = loadingCtrl;
        this.plt = plt;
    }
    ngOnInit() {
        this.checkMobile = this.plt.is('desktop');
        console.log(this.checkMobile);
    }
    ionViewWillEnter() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.iframeURL = this.getSafeUrl();
            // this.loading = await this.loadingCtrl.create({ message: 'Loading...' });
            // this.loading.present();
            // window.open (this.postServices.apiUrl + 'isi/' + this.post.id_rss);
            // this.loading.dismiss();
        });
    }
    getSafeUrl() {
        return this.domSanit.bypassSecurityTrustResourceUrl(this.post.permalink);
        // return this.domSanit.bypassSecurityTrustResourceUrl(this.postServices.apiUrl + 'isi/' + this.post.id_rss);
    }
    closeModal() {
        this.modalCtrl.dismiss();
    }
};
DetailComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__.DomSanitizer },
    { type: _services_post_service__WEBPACK_IMPORTED_MODULE_2__.PostsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.Platform }
];
DetailComponent.propDecorators = {
    post: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.Input }]
};
DetailComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-detail',
        template: _detail_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_detail_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DetailComponent);



/***/ }),

/***/ 7848:
/*!*********************************!*\
  !*** ./src/app/fft/fft.page.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FftPage": () => (/* binding */ FftPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _fft_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fft.page.html?ngResource */ 3648);
/* harmony import */ var _fft_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./fft.page.scss?ngResource */ 1291);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _ft_ft_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../ft/ft.page */ 9431);
/* harmony import */ var _services_post_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/post.service */ 9166);
/* harmony import */ var _detail_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../detail/detail.component */ 9337);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 318);












let FftPage = class FftPage {
    constructor(postServices, loadingCtrl, modalCtrl, Ft, AlertCtrl, routes, route, sanitizer, plt) {
        this.postServices = postServices;
        this.loadingCtrl = loadingCtrl;
        this.modalCtrl = modalCtrl;
        this.Ft = Ft;
        this.AlertCtrl = AlertCtrl;
        this.routes = routes;
        this.route = route;
        this.sanitizer = sanitizer;
        this.plt = plt;
        this.trial = new Date("3/31/2022");
        this.todayDate = new Date();
        this.itemListData = [];
        this.page = 1;
        this.a = 8;
        this.completed = false;
    }
    addHistory(post) {
        console.log(post);
        this.postServices.addHistory(post);
    }
    goToLink(url) {
        window.open(url, "_blank");
    }
    showImage(src) {
        return this.sanitizer.bypassSecurityTrustUrl(src);
    }
    handleImageError(e) {
        e.isSHOW = true;
    }
    getDataPost(isFirstLoad, event) {
        this.url = '?page=' + this.page;
        this.routes.params.subscribe((params) => this.kw = params['kw']);
        console.log(this.kw);
        console.log(this.Ft.kw);
        if (this.kw !== null) {
            this.postServices.getFt(this.kw, this.url)
                .subscribe((data) => {
                if (data.data.length !== 0) {
                    this.a = data.data.length;
                    for (let i = 0; i < this.a; i++) {
                        this.itemListData.push(data.data[i]);
                    }
                    if (isFirstLoad)
                        event.target.complete();
                    this.loading.dismiss();
                    this.page++;
                }
                else {
                    this.completed = true;
                }
            }, error => {
                console.log(error);
                this.loading.dismiss();
                this.AlertCtrl.create({
                    header: 'ERROR',
                    mode: 'ios',
                    subHeader: 'FT ini sudah tidak aktif',
                    message: 'Silahkan cari FT lain',
                    buttons: ['Tutup'],
                }).then(res => {
                    res.present();
                    this.route.navigate(['/ft']);
                });
            });
        }
        else {
            this.AlertCtrl.create({
                header: 'Info',
                mode: 'ios',
                subHeader: 'ERROR',
                message: 'Silahkan isi kata kunci pencarian',
                buttons: ['Tutup'],
            }).then(res => {
                res.present();
            });
            this.loading.dismiss();
        }
    }
    doInfinite(event) {
        this.getDataPost(true, event);
    }
    // ionViewDidLoad() {
    //   this.kw.subscribe((value) => { 
    //     console.log(value);
    //     if (true === value) {
    //       this.getDataPost(true, event);
    //     } else {
    //       this.getDataPost(false, event);
    //     }
    //  });
    // }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.loading = yield this.loadingCtrl.create({ message: 'Loading...' });
            this.loading.present();
            this.getDataPost(false, "");
            this.checkMobile = this.plt.is('desktop');
            console.log(this.checkMobile);
        });
    }
    openDetailModal(post) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _detail_detail_component__WEBPACK_IMPORTED_MODULE_4__.DetailComponent,
                componentProps: { post },
            });
            modal.present();
        });
    }
};
FftPage.ctorParameters = () => [
    { type: _services_post_service__WEBPACK_IMPORTED_MODULE_3__.PostsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _ft_ft_page__WEBPACK_IMPORTED_MODULE_2__.FtPage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.DomSanitizer },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform }
];
FftPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-post',
        template: _fft_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_fft_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FftPage);



/***/ }),

/***/ 9431:
/*!*******************************!*\
  !*** ./src/app/ft/ft.page.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FtPage": () => (/* binding */ FtPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ft_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ft.page.html?ngResource */ 8736);
/* harmony import */ var _ft_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ft.page.scss?ngResource */ 3057);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 8759);
/* harmony import */ var _services_post_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/post.service */ 9166);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 2816);








let FtPage = class FtPage {
    constructor(postServices, loadingCtrl, routes) {
        this.postServices = postServices;
        this.loadingCtrl = loadingCtrl;
        this.routes = routes;
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({ message: 'Loading...' });
            loading.present();
            this.fts$ = this.postServices.getFts().pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.tap)(fts => {
                loading.dismiss();
                return fts;
            }));
        });
    }
    goHref(ft) {
        this.kw = ft.url_ft.replace('/feed', '').replace('/rss.xml', '').replace('http://', '').replace('https://', '');
        console.log(this.kw);
        this.routes.navigateByUrl('/', { skipLocationChange: true }).then(() => this.routes.navigate(['/fft', this.kw]));
    }
};
FtPage.ctorParameters = () => [
    { type: _services_post_service__WEBPACK_IMPORTED_MODULE_2__.PostsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router }
];
FtPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-ft',
        template: _ft_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ft_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FtPage);



/***/ }),

/***/ 8461:
/*!***********************************!*\
  !*** ./src/app/post/post.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PostPage": () => (/* binding */ PostPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _post_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./post.page.html?ngResource */ 5070);
/* harmony import */ var _post_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./post.page.scss?ngResource */ 3293);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _services_post_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/post.service */ 9166);
/* harmony import */ var _detail_detail_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../detail/detail.component */ 9337);
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ 9128);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/storage.service */ 1188);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser */ 318);
/* harmony import */ var _awesome_cordova_plugins_background_mode_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @awesome-cordova-plugins/background-mode/ngx */ 4416);
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/storage */ 190);














let PostPage = class PostPage {
    constructor(postServices, storageServices, loadingCtrl, modalCtrl, storage, AlertCtrl, sanitizer, bgMode, plt, Storage) {
        this.postServices = postServices;
        this.storageServices = storageServices;
        this.loadingCtrl = loadingCtrl;
        this.modalCtrl = modalCtrl;
        this.storage = storage;
        this.AlertCtrl = AlertCtrl;
        this.sanitizer = sanitizer;
        this.bgMode = bgMode;
        this.plt = plt;
        this.Storage = Storage;
        this.trial = new Date("12/12/2023");
        this.todayDate = new Date();
        this.itemListData = [];
        this.page = 1;
        this.myFav = [];
        this.appver = 5;
        this.checkver = 0;
    }
    addHistory(post) {
        console.log(post);
        this.postServices.addHistory(post);
    }
    goToLink(url) {
        window.open(url, "_blank");
    }
    showImage(src) {
        return this.sanitizer.bypassSecurityTrustUrl(src);
    }
    handleImageError(image) {
        image.hide = true;
    }
    ionViewWillEnter() {
        this.Storage.set('checkver', true);
        this.postServices.getVer().subscribe((data) => {
            if (this.appver < data) {
                console.log(data);
                this.AlertCtrl.create({
                    header: 'Info',
                    mode: 'ios',
                    subHeader: 'Versi Baru Telah Tersedia',
                    message: 'Silahkan Unduh di Situs BerkasNovel',
                    buttons: [
                        // {
                        //   text: 'Update',
                        //   handler: () => {                 
                        //     window.open('https://berkasnovel.online/dl_berkasnovel.html', '_blank', 'location=no');                
                        //   }
                        // },
                        {
                            text: 'Tutup',
                        }
                    ],
                }).then(res => {
                    res.present();
                    this.Storage.set('checkver', false);
                });
            }
        });
    }
    ;
    addFavorite(post) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.myFav.push(post);
            // this.storage.setItem(this.myFav[arr + 1], post);    
            // console.log(this.myFav);
            this.storage.setItem('listFav', JSON.stringify(this.myFav));
            this.storage.getItem('listFav').then((val) => {
                console.log(JSON.parse(val));
            });
        });
    }
    removeFavorite(post) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            let index = this.myFav.indexOf(post);
            if (index > -1) {
                this.myFav.splice(index, 1);
            }
            console.log(this.myFav);
            this.storage.setItem('listFav', JSON.stringify(this.myFav));
            this.storage.getItem('listFav').then((val) => {
                console.log(JSON.parse(val));
            });
        });
    }
    getDataPost(isFirstLoad, event) {
        const self = this;
        this.url = '?page=' + this.page;
        this.postServices.getPosts(this.url)
            .subscribe((data) => {
            // console.log(data.data[0].id_rss);
            for (let i = 0; i < data.data.length; i++) {
                this.itemListData.push(data.data[i]);
            }
            if (isFirstLoad)
                event.target.complete();
            this.loading.dismiss();
            this.page++;
            if (this.idOld < this.itemListData[0].id_rss) {
                console.log('Wayahe Update');
                this.storageServices.set('last', this.itemListData[0].id_rss);
            }
        }, error => {
            console.log(error);
        });
    }
    doInfinite(event) {
        this.getDataPost(true, event);
    }
    setArr(arrTemp) {
        for (let i = 0; i < arrTemp.length; i++) {
            this.myFav.push(arrTemp[i]);
        }
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            console.log(this.checkver);
            if (this.trial >= this.todayDate) {
                this.loading = yield this.loadingCtrl.create({ message: 'Loading...' });
                this.loading.present();
                this.getDataPost(false, "");
                this.idOld = yield this.storageServices.get('last');
                this.bgMode.enable();
                this.checkMobile = this.plt.is('desktop');
                this.plt.platforms();
                console.log(this.checkMobile);
                console.log(this.plt.platforms());
                this.storage.getItem('listFav').then((val) => {
                    this.arrTemp = JSON.parse(val);
                    this.setArr(this.arrTemp);
                    console.log(this.myFav);
                });
            }
            else {
                const loading = yield this.loadingCtrl.create({ message: 'Masa Beta Test Sudah Lewat, Silahkan kunjungi Fanspage BerkasNovel untuk Informasi Lebih Lanjut...' });
                loading.present();
            }
        });
    }
    openDetailModal(post) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _detail_detail_component__WEBPACK_IMPORTED_MODULE_3__.DetailComponent,
                componentProps: { post },
            });
            modal.present();
        });
    }
};
PostPage.ctorParameters = () => [
    { type: _services_post_service__WEBPACK_IMPORTED_MODULE_2__.PostsService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_5__.StorageService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController },
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_4__.NativeStorage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.DomSanitizer },
    { type: _awesome_cordova_plugins_background_mode_ngx__WEBPACK_IMPORTED_MODULE_6__.BackgroundMode },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.Platform },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__.Storage }
];
PostPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-post',
        template: _post_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_post_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PostPage);



/***/ }),

/***/ 8064:
/*!***************************************!*\
  !*** ./src/app/redirect.component.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RedirectComponent": () => (/* binding */ RedirectComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 3184);


let RedirectComponent = class RedirectComponent {
    constructor() { }
    ngOnInit() {
        window.open('https://berkasnovel.online/BerkasNovel%20Beta.apk', '_blank');
        window.location.href = "/";
    }
};
RedirectComponent.ctorParameters = () => [];
RedirectComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Component)({
        selector: 'redirect',
        template: 'Proses Download Segera dimulai...'
    })
], RedirectComponent);



/***/ }),

/***/ 9166:
/*!******************************************!*\
  !*** ./src/app/services/post.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PostsService": () => (/* binding */ PostsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 8784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ 9128);




let PostsService = class PostsService {
    constructor(http, storage) {
        this.http = http;
        this.storage = storage;
        this.apiUrl = 'https://berkasnovel.online/api/';
        this.myHistory = [];
    }
    getPosts(page) {
        return this.http.get(this.apiUrl + 'post' + page);
    }
    getFav(kw, page) {
        console.log(this.apiUrl + 'fav/' + kw + page);
        return this.http.get(this.apiUrl + 'fav/' + kw + page);
    }
    getHistory(kw, page) {
        return this.http.get(this.apiUrl + 'fav/' + kw + page);
    }
    getNovel(kw, page) {
        console.log(this.apiUrl + 'cari/' + kw + page);
        return this.http.get(this.apiUrl + 'cari/' + kw + page);
    }
    getFt(kw, page) {
        console.log(this.apiUrl + 'ft/' + kw + page);
        return this.http.get(this.apiUrl + 'ft/' + kw + page);
    }
    getFts() {
        return this.http.get(this.apiUrl + 'listft');
    }
    getVer() {
        return this.http.get(this.apiUrl + 'ver');
    }
    addHistory(post) {
        // this.myHistory = JSON.parse(this.storage.getItem('listHistory'));  
        this.storage.getItem('listHistory').then((val) => {
            this.myHistory = JSON.parse(val);
            this.myHistory.push(post);
            this.storage.setItem('listHistory', JSON.stringify(this.myHistory.reverse()));
        });
    }
};
PostsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient },
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_0__.NativeStorage }
];
PostsService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], PostsService);



/***/ }),

/***/ 1188:
/*!*********************************************!*\
  !*** ./src/app/services/storage.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StorageService": () => (/* binding */ StorageService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/storage-angular */ 190);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);



let StorageService = class StorageService {
    constructor(storage) {
        this.storage = storage;
        this._storage = null;
        this.init();
    }
    init() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            // If using, define drivers here: await this.storage.defineDriver(/*...*/);
            const storage = yield this.storage.create();
            this._storage = storage;
        });
    }
    set(key, value) {
        var _a;
        (_a = this._storage) === null || _a === void 0 ? void 0 : _a.set(key, value);
    }
    get(key) {
        const data = this.storage.get(key);
        return data;
    }
};
StorageService.ctorParameters = () => [
    { type: _ionic_storage_angular__WEBPACK_IMPORTED_MODULE_1__.Storage }
];
StorageService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], StorageService);



/***/ }),

/***/ 2340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 4431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 8150);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 6747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 2340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		79,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		5593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		3225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		6655,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		4856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		3059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		8648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		8308,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		4690,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		4090,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		6214,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		9447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		9689,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		8840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		9667,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		3288,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		5473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		3634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		2855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		8737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		9632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		4446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		2275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		8050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		8994,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		3592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		5454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		2666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		4816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		5534,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		4902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		1938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		8179,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		1624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		9989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		8902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		8395,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		6357,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		8268,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		5269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		2875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 9259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #616e7e;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-primary);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #73849a;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFxJb25pYyUyMFRlc3RcXGNydWRcXHNyY1xcYXBwXFxhcHAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSwyRUFBQTtBQ0NGOztBREVBO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7QUNDRjs7QURFQTtFQUNFLGVBQUE7QUNDRjs7QURFQTtFQUNFLG1CQUFBO0FDQ0Y7O0FERUE7O0VBRUUsa0JBQUE7QUNDRjs7QURFQTtFQUNFLDJEQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFFQSxnQkFBQTtBQ0FGOztBREdBO0VBQ0UsZUFBQTtFQUVBLG1CQUFBO0VBRUEsY0FBQTtFQUVBLGdCQUFBO0FDSEY7O0FETUE7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUNIRjs7QURNQTtFQUNFLHNEQUFBO0FDSEY7O0FETUE7RUFDRSwrQkFBQTtBQ0hGOztBRE1BO0VBQ0UsY0FBQTtBQ0hGOztBRE1BO0VBQ0UsZ0JBQUE7QUNIRjs7QURNQTtFQUNFLHNCQUFBO0FDSEY7O0FETUE7RUFDRSxtQkFBQTtBQ0hGOztBRE1BO0VBQ0UsaUJBQUE7RUFDQSxtQkFBQTtBQ0hGOztBRE1BO0VBQ0UscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FDSEY7O0FETUE7RUFDRSwrQkFBQTtBQ0hGOztBRE1BO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUNIRjs7QURNQTtFQUNFLGtCQUFBO0FDSEY7O0FETUE7O0VBRUUsa0JBQUE7RUFDQSxtQkFBQTtBQ0hGOztBRE1BO0VBQ0Usa0JBQUE7QUNIRjs7QURNQTtFQUNFLHFCQUFBO0VBQ0EsZUFBQTtFQUVBLG9DQUFBO0FDSkY7O0FET0E7RUFDRSxpQ0FBQTtBQ0pGIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1tZW51IGlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24taXRlbS1iYWNrZ3JvdW5kLCB2YXIoLS1pb24tYmFja2dyb3VuZC1jb2xvciwgI2ZmZikpO1xufVxuXG5pb24tbWVudS5tZCBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1zdGFydDogOHB4O1xuICAtLXBhZGRpbmctZW5kOiA4cHg7XG4gIC0tcGFkZGluZy10b3A6IDIwcHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0IHtcbiAgcGFkZGluZzogMjBweCAwO1xufVxuXG5pb24tbWVudS5tZCBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xufVxuXG5pb24tbWVudS5tZCBpb24tbGlzdCNpbmJveC1saXN0IHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTE1MCwgI2Q3ZDhkYSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBmb250LXdlaWdodDogNjAwO1xuXG4gIG1pbi1oZWlnaHQ6IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIGZvbnQtc2l6ZTogMTZweDtcblxuICBtYXJnaW4tYm90dG9tOiAxOHB4O1xuXG4gIGNvbG9yOiAjNzU3NTc1O1xuXG4gIG1pbi1oZWlnaHQ6IDI2cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAtLXBhZGRpbmctZW5kOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiksIDAuMTQpO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgY29sb3I6ICM2MTZlN2U7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gIC0tbWluLWhlaWdodDogNTBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBjb2xvcjogIzczODQ5YTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgcGFkZGluZy1yaWdodDogMTZweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuXG5pb24tbm90ZSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC1zaXplOiAxNnB4O1xuXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXNoYWRlKTtcbn1cblxuaW9uLWl0ZW0uc2VsZWN0ZWQge1xuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59IiwiaW9uLW1lbnUgaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1pdGVtLWJhY2tncm91bmQsIHZhcigtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yLCAjZmZmKSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1jb250ZW50IHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDhweDtcbiAgLS1wYWRkaW5nLXRvcDogMjBweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3Qge1xuICBwYWRkaW5nOiAyMHB4IDA7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QtaGVhZGVyLFxuaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3Qge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXN0ZXAtMTUwLCAjZDdkOGRhKTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QjaW5ib3gtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBmb250LXNpemU6IDIycHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIG1pbi1oZWlnaHQ6IDIwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luLWJvdHRvbTogMThweDtcbiAgY29sb3I6ICM3NTc1NzU7XG4gIG1pbi1oZWlnaHQ6IDI2cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xuICAtLXBhZGRpbmctZW5kOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1iYWNrZ3JvdW5kOiByZ2JhKHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LXJnYiksIDAuMTQpO1xufVxuXG5pb24tbWVudS5tZCBpb24taXRlbS5zZWxlY3RlZCBpb24taWNvbiB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgY29sb3I6ICM2MTZlN2U7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gIC0tbWluLWhlaWdodDogNTBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNHB4O1xuICBjb2xvcjogIzczODQ5YTtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0I2xhYmVscy1saXN0IGlvbi1saXN0LWhlYWRlciB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1saXN0LWhlYWRlcixcbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgcGFkZGluZy1yaWdodDogMTZweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1ub3RlIHtcbiAgbWFyZ2luLWJvdHRvbTogOHB4O1xufVxuXG5pb24tbm90ZSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC1zaXplOiAxNnB4O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG59XG5cbmlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufSJdfQ== */";

/***/ }),

/***/ 1314:
/*!*********************************************************!*\
  !*** ./src/app/detail/detail.component.scss?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "ion-content div.scroll {\n  height: 90%;\n}\n\n.webPage {\n  width: 100%;\n  height: 100%;\n  background-color: transparent;\n  overflow: hidden;\n}\n\n.btn-tutup {\n  position: fixed;\n  left: 0;\n  bottom: 10px;\n  right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbC5jb21wb25lbnQuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcSW9uaWMlMjBUZXN0XFxjcnVkXFxzcmNcXGFwcFxcZGV0YWlsXFxkZXRhaWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0FDQ0o7O0FERUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0JBQUE7QUNDSjs7QURFRTtFQUNFLGVBQUE7RUFDQSxPQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7QUNDSiIsImZpbGUiOiJkZXRhaWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCBkaXYuc2Nyb2xse1xyXG4gICAgaGVpZ2h0OiA5MCU7XHJcbiAgfVxyXG4gIFxyXG4gIC53ZWJQYWdle1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW4gO1xyXG4gIH1cclxuXHJcbiAgLmJ0bi10dXR1cCB7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgYm90dG9tOiAxMHB4O1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgfSIsImlvbi1jb250ZW50IGRpdi5zY3JvbGwge1xuICBoZWlnaHQ6IDkwJTtcbn1cblxuLndlYlBhZ2Uge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuLmJ0bi10dXR1cCB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgbGVmdDogMDtcbiAgYm90dG9tOiAxMHB4O1xuICByaWdodDogMDtcbn0iXX0= */";

/***/ }),

/***/ 1291:
/*!**********************************************!*\
  !*** ./src/app/fft/fft.page.scss?ngResource ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmZnQucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 3057:
/*!********************************************!*\
  !*** ./src/app/ft/ft.page.scss?ngResource ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJmdC5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 3293:
/*!************************************************!*\
  !*** ./src/app/post/post.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwb3N0LnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 3383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\n  <!-- <ion-split-pane when=\"false\"  contentId=\"main-content\"> -->\n  <ion-split-pane contentId=\"main-content\">\n  <ion-menu contentId=\"main-content\" type=\"overlay\">\n    <ion-content>\n      <ion-list id=\"inbox-list\">\n        <ion-list-header>BerkasNovel</ion-list-header>\n        <ion-note>Tempat Baca Novel Terjemahan</ion-note>\n        <iframe src=\"https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FBerkasNovel&amp;tabs&amp;width=500&amp;height=70&amp;small_header=true&amp;adapt_container_width=true&amp;hide_cover=false&amp;show_facepile=true&amp;appId=366781520125931\" height=\"100px\" width=\"500px\" class=\"mx-auto ion-padding\" style=\"border:none;overflow:hidden\" scrolling=\"no\" frameborder=\"0\" allowfullscreen=\"true\" allow=\"autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share\"></iframe>\n        <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\n          <ion-item routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\"\n            routerLinkActive=\"selected\">\n            <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\n            <ion-label>{{ p.title }}</ion-label>\n          </ion-item>\n        </ion-menu-toggle>\n      </ion-list>\n\n      <form [formGroup]='form' (ngSubmit)=\"CariNovel()\">\n        <ion-item>\n          <ion-icon slot=\"start\" icon=\"search\"></ion-icon>\n          <ion-label position=\"floating\">Cari Novel...</ion-label>\n          <ion-input menuClose=\"left\" required formControlName=\"kw\" type=\"text\"></ion-input>\n        </ion-item>\n        <!-- <ion-button expand=\"block\"color=\"primary\" type=\"submit\"(click)=\"CariNovel()\">\n            Cari\n          </ion-button> -->\n      </form>\n\n      <ion-list id=\"labels-list\">\n        <ion-list-header>About</ion-list-header>\n\n        <ion-item *ngFor=\"let label of labels\" lines=\"none\">\n          <ion-note>{{ label }}</ion-note>\n        </ion-item>\n      </ion-list>\n    </ion-content>\n  </ion-menu>\n  <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n";

/***/ }),

/***/ 5554:
/*!*********************************************************!*\
  !*** ./src/app/detail/detail.component.html?ngResource ***!
  \*********************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title>{{post.title}}\n      <ion-buttons slot=\"end\">\n        <ion-button (click)=\"closeModal()\">\n          <ion-icon slot=\"start\" name=\"close\"></ion-icon>\n        </ion-button>\n      </ion-buttons>\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!-- <div [innerHTML]=\"isi\"></div> -->\n  <iframe [src]=\"iframeURL\" target=\"_parent\" class=\"webPage\" frameborder=\"0\"></iframe>\n  <ion-button class=\"btn-tutup\" (click)=\"closeModal()\" color=\"primary\">\n    <ion-icon slot=\"start\" name=\"add\"></ion-icon>\n    Tutup\n  </ion-button>\n</ion-content>\n";

/***/ }),

/***/ 3648:
/*!**********************************************!*\
  !*** ./src/app/fft/fft.page.html?ngResource ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-row>\n      <ion-menu-toggle>\n        <ion-button fill=\"clear\">\n          <ion-icon size=\"large\" name=\"menu-outline\"></ion-icon>\n        </ion-button>\n      </ion-menu-toggle>\n      <ion-title class=\"ion-text-justify\">List Update</ion-title>\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-row wrap>\n      <ion-col size-lg=\"6\" size-md=\"12\" size-sm=\"12\" size-xs=\"12\" size=\"auto\" *ngFor=\"let post of itemListData\">     \n        <ion-card *ngIf=\"checkMobile == true;else elsemobile\" (click)=\"goToLink(post.permalink); addHistory(post.id_rss)\">\n          <ion-grid fixed>           \n            <ion-row>\n              <ion-col size=\"4\">\n                <img height=\"400\" width=\"600\" referrerpolicy=\"no-referrer\" attr=\"referrerpolicy:no-referrer\"\n                  [src]=\"showImage(post.thumb)\" class=\"img-thumb\" />\n              </ion-col>\n              <ion-col size=\"8\">\n                <ion-card-content>\n                  <ion-card-title style=\"text-align: center;padding-bottom: 5%;\">{{post.ft}}</ion-card-title>\n                  <ion-card-subtitle>{{post.title}}</ion-card-subtitle>\n                  <ion-text>\n                    <div class=\"ion-text-center\" style=\"padding-top:3%;\">\n                      {{post.timestamp * 1000 | date: 'dd MMMM yyyy'}}</div>\n                  </ion-text>\n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card>\n\n        <ng-template #elsemobile>\n          <ion-card (click)=\"openDetailModal(post); addHistory(post.id_rss)\">\n            <ion-grid fixed>             \n              <ion-row>\n                <ion-col size=\"4\">\n                  <img height=\"400\" width=\"600\" referrerpolicy=\"no-referrer\" attr=\"referrerpolicy:no-referrer\"\n                    [src]=\"showImage(post.thumb)\" class=\"img-thumb\" />\n                </ion-col>\n                <ion-col size=\"8\">\n                  <ion-card-content>\n                    <ion-card-title style=\"text-align: center;padding-bottom: 5%;\">{{post.ft}}</ion-card-title>\n                    <ion-card-subtitle>{{post.title}}</ion-card-subtitle>\n                    <ion-text>\n                      <div class=\"ion-text-center\" style=\"padding-top:3%;\">\n                        {{post.timestamp * 1000 | date: 'dd MMMM yyyy'}}</div>\n                    </ion-text>\n                  </ion-card-content>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-card>\n        </ng-template>\n\n      </ion-col>\n    </ion-row>\n  </ion-list>\n\n  <ion-infinite-scroll *ngIf=\"completed == false\" (ionInfinite)=\"doInfinite($event)\">\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n</ion-content>\n";

/***/ }),

/***/ 8736:
/*!********************************************!*\
  !*** ./src/app/ft/ft.page.html?ngResource ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-row>\n      <ion-menu-toggle>\n        <ion-button  fill=\"clear\">\n          <ion-icon size=\"large\"  name=\"menu-outline\"></ion-icon>\n        </ion-button>\n      </ion-menu-toggle>\n      <ion-title class=\"ion-text-justify\">Daftar Fan Translation</ion-title>\n    </ion-row>   \n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-card>\n      <ion-grid fixed>\n        <ion-row wrap>          \n          <ion-col size-lg=\"6\" size-md=\"12\" *ngFor=\"let fts of fts$|async\">\n            <ion-card-content (click)=\"goHref(fts)\">\n              <ion-card-title style=\"text-align: center;\">{{fts.nama_ft}}</ion-card-title>\n              <ion-card-subtitle style=\"text-align: center\">{{fts.url_ft.replace('/feed','').replace('/rss.xml','')}}</ion-card-subtitle>            \n            </ion-card-content>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n  </ion-list>\n\n</ion-content>\n";

/***/ }),

/***/ 5070:
/*!************************************************!*\
  !*** ./src/app/post/post.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-row>\n      <ion-menu-toggle>\n        <ion-button fill=\"clear\">\n          <ion-icon size=\"large\" name=\"menu-outline\"></ion-icon>\n        </ion-button>\n      </ion-menu-toggle>\n      <ion-title class=\"ion-text-justify\">Daftar Update Novel</ion-title>\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>  \n  <ion-list>\n    <ion-row wrap>\n      <ion-col size-lg=\"6\" size-md=\"12\" size-sm=\"12\" size-xs=\"12\" size=\"auto\" *ngFor=\"let post of itemListData\">     \n        <ion-card *ngIf=\"checkMobile == true;else elsemobile\">\n          <ion-grid fixed>            \n            <ion-row>\n              <ion-col size=\"4\" (click)=\"goToLink(post.permalink); addHistory(post.id_rss)\">\n                <img height=\"400\" width=\"600\" referrerpolicy=\"no-referrer\" attr=\"referrerpolicy:no-referrer\"\n                  [src]=\"showImage(post.thumb)\" class=\"img-thumb\" />\n              </ion-col>\n              <ion-col size=\"8\">\n                <ion-row style=\"position:initial;top: 0;padding-bottom: 10%;\">\n\n                  <ion-badge *ngIf=\"idOld < post.id_rss\"\n                    style=\"position:absolute;margin:5;left: 0;background-color: #2144C0;\">\n                    Update Baru\n                  </ion-badge>\n\n                  <ng-template #addFav>\n                    <ion-button size=\"small\" color=\"danger\" style=\"position:absolute;right: 0;padding:50;margin-top: 0;\"\n                      (click)=\"addFavorite(post.id_rss)\">\n                      <ion-icon slot=\"start\" name=\"heart-outline\"></ion-icon>\n                      <span>Favorites</span>\n                    </ion-button>\n                  </ng-template>\n\n                  <ion-button *ngIf=\"myFav.includes(post.id_rss);else addFav\" size=\"small\" color=\"danger\"\n                    style=\"position:absolute;right: 0;padding:50;margin-top: 0;\" (click)=\"removeFavorite(post.id_rss)\">\n                    <ion-icon slot=\"start\" name=\"heart-dislike-outline\"></ion-icon>\n                    <span>Favorites</span>\n                  </ion-button>\n\n                </ion-row>\n                <ion-card-content (click)=\"goToLink(post.permalink); addHistory(post.id_rss)\">\n                  <ion-card-title style=\"text-align: center;padding-bottom: 5%;\">{{post.ft}}</ion-card-title>\n                  <ion-card-subtitle>{{post.title}}</ion-card-subtitle>\n                  <ion-text>\n                    <div class=\"ion-text-center\" style=\"padding-top:3%;\">\n                      {{post.timestamp * 1000 | date: 'dd MMMM yyyy'}}</div>\n                  </ion-text>\n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card>\n\n        <ng-template #elsemobile>\n          <ion-card >\n            <ion-grid fixed>              \n              <ion-row>\n                <ion-col size=\"4\" (click)=\"openDetailModal(post); addHistory(post.id_rss)\">\n                  <img height=\"400\" width=\"600\" referrerpolicy=\"no-referrer\" attr=\"referrerpolicy:no-referrer\"\n                    [src]=\"showImage(post.thumb)\" class=\"img-thumb\" />\n                </ion-col>\n                <ion-col size=\"8\">\n                  <ion-row style=\"position:initial;top: 0;padding-bottom: 10%;\">\n\n                    <ion-badge *ngIf=\"idOld < post.id_rss\"\n                      style=\"position:absolute;margin:5;left: 0;background-color: #2144C0;\">\n                      Update Baru\n                    </ion-badge>\n  \n                    <ng-template #addFav>\n                      <ion-button size=\"small\" color=\"danger\" style=\"position:absolute;right: 0;padding:50;margin-top: 0;\"\n                        (click)=\"addFavorite(post.id_rss)\">\n                        <ion-icon slot=\"start\" name=\"heart-outline\"></ion-icon>\n                        <span>Favorites</span>\n                      </ion-button>\n                    </ng-template>\n  \n                    <ion-button *ngIf=\"myFav.includes(post.id_rss);else addFav\" size=\"small\" color=\"danger\"\n                      style=\"position:absolute;right: 0;padding:50;margin-top: 0;\" (click)=\"removeFavorite(post.id_rss)\">\n                      <ion-icon slot=\"start\" name=\"heart-dislike-outline\"></ion-icon>\n                      <span>Favorites</span>\n                    </ion-button>\n  \n                  </ion-row>\n                  <ion-card-content (click)=\"openDetailModal(post); addHistory(post.id_rss)\">\n                    <ion-card-title style=\"text-align: center;padding-bottom: 5%;\">{{post.ft}}</ion-card-title>\n                    <ion-card-subtitle>{{post.title}}</ion-card-subtitle>\n                    <ion-text>\n                      <div class=\"ion-text-center\" style=\"padding-top:3%;\">\n                        {{post.timestamp * 1000 | date: 'dd MMMM yyyy'}}</div>\n                    </ion-text>\n                  </ion-card-content>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-card>\n        </ng-template>\n\n      </ion-col>\n    </ion-row>\n  </ion-list>\n\n  <ion-infinite-scroll (ionInfinite)=\"doInfinite($event)\">\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n</ion-content>\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(4431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map