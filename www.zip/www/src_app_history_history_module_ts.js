"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_history_history_module_ts"],{

/***/ 5010:
/*!***************************************************!*\
  !*** ./src/app/history/history-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistoryPageRoutingModule": () => (/* binding */ HistoryPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _history_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./history.page */ 4253);




const routes = [
    {
        path: '',
        component: _history_page__WEBPACK_IMPORTED_MODULE_0__.HistoryPage
    }
];
let HistoryPageRoutingModule = class HistoryPageRoutingModule {
};
HistoryPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HistoryPageRoutingModule);



/***/ }),

/***/ 2486:
/*!*******************************************!*\
  !*** ./src/app/history/history.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistoryPageModule": () => (/* binding */ HistoryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _history_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./history-routing.module */ 5010);
/* harmony import */ var _history_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./history.page */ 4253);







let HistoryPageModule = class HistoryPageModule {
};
HistoryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _history_routing_module__WEBPACK_IMPORTED_MODULE_0__.HistoryPageRoutingModule,
        ],
        declarations: [_history_page__WEBPACK_IMPORTED_MODULE_1__.HistoryPage]
    })
], HistoryPageModule);



/***/ }),

/***/ 4253:
/*!*****************************************!*\
  !*** ./src/app/history/history.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HistoryPage": () => (/* binding */ HistoryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _history_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./history.page.html?ngResource */ 7850);
/* harmony import */ var _history_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./history.page.scss?ngResource */ 6256);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app.component */ 5041);
/* harmony import */ var _services_post_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/post.service */ 9166);
/* harmony import */ var _detail_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../detail/detail.component */ 9337);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser */ 318);
/* harmony import */ var _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/native-storage/ngx */ 9128);
/* harmony import */ var _post_post_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../post/post.page */ 8461);















let HistoryPage = class HistoryPage {
    constructor(postServices, loadingCtrl, modalCtrl, App, AlertCtrl, menuCtrl, route, sanitizer, storage, postPage, plt) {
        this.postServices = postServices;
        this.loadingCtrl = loadingCtrl;
        this.modalCtrl = modalCtrl;
        this.App = App;
        this.AlertCtrl = AlertCtrl;
        this.menuCtrl = menuCtrl;
        this.route = route;
        this.sanitizer = sanitizer;
        this.storage = storage;
        this.postPage = postPage;
        this.plt = plt;
        this.trial = new Date("3/31/2022");
        this.todayDate = new Date();
        this.itemListData = [];
        this.page = 1;
        this.a = 8;
        this.myHistory = [];
        this.arrTemp = [];
        this.completed = false;
    }
    showImage(src) {
        return this.sanitizer.bypassSecurityTrustUrl(src);
    }
    getDataPost(isFirstLoad, event) {
        this.url = '?page=' + this.page;
        this.kw = this.storage.getItem('listHistory').then((val) => {
            var list = val.toString();
            console.log(list);
            this.postServices.getHistory(list, this.url)
                .subscribe((data) => {
                if (data.data.length !== 0) {
                    this.a = data.data.length;
                    for (let i = 0; i < this.a; i++) {
                        this.itemListData.push(data.data[i]);
                    }
                    if (isFirstLoad)
                        event.target.complete();
                    this.loading.dismiss();
                    this.page++;
                }
                else {
                    this.completed = true;
                }
            }, error => {
                this.completed = true;
                this.loading.dismiss();
                this.route.navigate(['/post']);
                console.log(error);
            });
            this.loading.dismiss();
        });
    }
    doInfinite(event) {
        this.getDataPost(true, event);
    }
    ionViewDidLoad() {
        this.kw.subscribe((value) => {
            console.log(value);
            if (true === value) {
                this.getDataPost(true, event);
            }
            else {
                this.getDataPost(false, event);
            }
        });
    }
    setArr(arrTemp) {
        for (let i = 0; i < arrTemp.length; i++) {
            this.myHistory.push(arrTemp[i]);
        }
    }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            console.log(this.plt.is('android'));
            if (this.plt.is('android') == false || this.plt.is('mobileweb') == true) {
                this.AlertCtrl.create({
                    header: 'Info',
                    mode: 'ios',
                    subHeader: 'Fitur Hanya Tersedia di Aplikasi Mobile',
                    message: 'Silahkan Tunggu Sampai Update Berikutnya',
                    buttons: ['Tutup'],
                }).then(res => {
                    res.present();
                    this.route.navigateByUrl('/history', { skipLocationChange: true }).then(() => this.route.navigate(['/post']));
                });
            }
            else {
                this.loading = yield this.loadingCtrl.create({ message: 'Loading...' });
                this.getDataPost(false, "");
                this.storage.getItem('listHistory').then((val) => {
                    this.loading.present();
                    this.arrTemp = JSON.parse(val);
                    this.setArr(this.arrTemp);
                    this.loading.dismiss();
                });
            }
        });
    }
    openDetailModal(post) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _detail_detail_component__WEBPACK_IMPORTED_MODULE_4__.DetailComponent,
                componentProps: { post },
            });
            modal.present();
        });
    }
};
HistoryPage.ctorParameters = () => [
    { type: _services_post_service__WEBPACK_IMPORTED_MODULE_3__.PostsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.ModalController },
    { type: _app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_10__.DomSanitizer },
    { type: _ionic_native_native_storage_ngx__WEBPACK_IMPORTED_MODULE_5__.NativeStorage },
    { type: _post_post_page__WEBPACK_IMPORTED_MODULE_6__.PostPage },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.Platform }
];
HistoryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-post',
        template: _history_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_history_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HistoryPage);



/***/ }),

/***/ 6256:
/*!******************************************************!*\
  !*** ./src/app/history/history.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJoaXN0b3J5LnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 7850:
/*!******************************************************!*\
  !*** ./src/app/history/history.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-row>\n      <ion-menu-toggle>\n        <ion-button fill=\"clear\">\n          <ion-icon size=\"large\" name=\"menu-outline\"></ion-icon>\n        </ion-button>\n      </ion-menu-toggle>\n      <ion-title class=\"ion-text-justify\">Daftar History</ion-title>\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-card *ngFor=\"let post of itemListData\">\n      <ion-grid fixed>\n        <ion-row>\n          <ion-col size=\"4\" (click)=\"openDetailModal(post)\">         \n            <img *ngIf=\"!post.hide\" height=\"400\" width=\"600\" referrerpolicy=\"no-referrer\"\n              attr=\"referrerpolicy:no-referrer\" [src]=\"showImage(post.thumb)\" class=\"img-thumb\"/>\n          </ion-col>\n          <ion-col size=\"8\">\n            <ion-card-content class=\"ion-align-items-center ion-text-center\" (click)=\"openDetailModal(post)\">\n              <ion-card-title style=\"text-align: center;padding-bottom: 5%;\">{{post.ft}}</ion-card-title>\n              <ion-card-subtitle>{{post.title}}</ion-card-subtitle>\n              <ion-text>\n                <div class=\"ion-text-center\" style=\"padding-top:3%;color: white;\">\n                  {{post.timestamp * 1000 | date: 'dd MMMM yyyy'}}</div>\n              </ion-text>\n            </ion-card-content>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-card>\n  </ion-list>\n\n  <ion-infinite-scroll *ngIf=\"completed == false\" (ionInfinite)=\"doInfinite($event)\">\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_history_history_module_ts.js.map