"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_cari_cari_module_ts"],{

/***/ 5753:
/*!*********************************************!*\
  !*** ./src/app/cari/cari-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CariPageRoutingModule": () => (/* binding */ CariPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _cari_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cari.page */ 1354);




const routes = [
    {
        path: '',
        component: _cari_page__WEBPACK_IMPORTED_MODULE_0__.CariPage
    }
];
let CariPageRoutingModule = class CariPageRoutingModule {
};
CariPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CariPageRoutingModule);



/***/ }),

/***/ 9046:
/*!*************************************!*\
  !*** ./src/app/cari/cari.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CariPageModule": () => (/* binding */ CariPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _cari_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cari-routing.module */ 5753);
/* harmony import */ var _cari_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cari.page */ 1354);







let CariPageModule = class CariPageModule {
};
CariPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _cari_routing_module__WEBPACK_IMPORTED_MODULE_0__.CariPageRoutingModule,
        ],
        declarations: [_cari_page__WEBPACK_IMPORTED_MODULE_1__.CariPage]
    })
], CariPageModule);



/***/ }),

/***/ 1354:
/*!***********************************!*\
  !*** ./src/app/cari/cari.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CariPage": () => (/* binding */ CariPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _cari_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cari.page.html?ngResource */ 880);
/* harmony import */ var _cari_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cari.page.scss?ngResource */ 7249);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../app.component */ 5041);
/* harmony import */ var _services_post_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/post.service */ 9166);
/* harmony import */ var _detail_detail_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../detail/detail.component */ 9337);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/platform-browser */ 318);













let CariPage = class CariPage {
    constructor(postServices, loadingCtrl, modalCtrl, App, AlertCtrl, menuCtrl, route, sanitizer, plt) {
        this.postServices = postServices;
        this.loadingCtrl = loadingCtrl;
        this.modalCtrl = modalCtrl;
        this.App = App;
        this.AlertCtrl = AlertCtrl;
        this.menuCtrl = menuCtrl;
        this.route = route;
        this.sanitizer = sanitizer;
        this.plt = plt;
        this.trial = new Date("3/31/2022");
        this.todayDate = new Date();
        this.itemListData = [];
        this.page = 1;
        this.a = 8;
        this.completed = false;
    }
    addHistory(post) {
        console.log(post);
        this.postServices.addHistory(post);
    }
    goToLink(url) {
        window.open(url, "_blank");
    }
    showImage(src) {
        return this.sanitizer.bypassSecurityTrustUrl(src);
    }
    getDataPost(isFirstLoad, event) {
        this.url = '?page=' + this.page;
        this.kw = this.App.kw;
        console.log(this.kw);
        if (this.kw !== null) {
            this.postServices.getNovel(this.kw, this.url)
                .subscribe((data) => {
                if (data.data.length !== 0) {
                    this.a = data.data.length;
                    for (let i = 0; i < this.a; i++) {
                        this.itemListData.push(data.data[i]);
                    }
                    if (isFirstLoad)
                        event.target.complete();
                    this.loading.dismiss();
                    this.page++;
                    this.checkData = true;
                }
                else {
                    this.completed = true;
                    if (this.checkData !== true && this.itemListData.length < 1) {
                        this.route.navigate(['/post']);
                        this.AlertCtrl.create({
                            header: 'Info',
                            mode: 'ios',
                            subHeader: 'Novel ' + this.kw + ' tidak ditemukan',
                            message: 'Silahkan cari dengan kata kunci lain',
                            buttons: ['Tutup'],
                        }).then(res => {
                            res.present();
                        });
                        this.loading.dismiss();
                    }
                }
            }, error => {
                console.log(error);
            });
        }
        else {
            this.AlertCtrl.create({
                header: 'Info',
                mode: 'ios',
                subHeader: 'ERROR',
                message: 'Silahkan isi kata kunci pencarian',
                buttons: ['Tutup'],
            }).then(res => {
                res.present();
            });
            this.loading.dismiss();
            this.route.navigate(['/post']);
        }
    }
    doInfinite(event) {
        this.getDataPost(true, event);
    }
    // ionViewDidLoad() {
    //   this.kw.subscribe((value) => { 
    //     console.log(value);
    //     if (true === value) {
    //       this.getDataPost(true, event);
    //     } else {
    //       this.getDataPost(false, event);
    //     }
    //  });
    // }
    ngOnInit() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            this.loading = yield this.loadingCtrl.create({ message: 'Loading...' });
            this.loading.present();
            this.getDataPost(false, "");
            this.checkMobile = this.plt.is('desktop');
            console.log(this.checkMobile);
        });
    }
    openDetailModal(post) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _detail_detail_component__WEBPACK_IMPORTED_MODULE_4__.DetailComponent,
                componentProps: { post },
            });
            modal.present();
        });
    }
};
CariPage.ctorParameters = () => [
    { type: _services_post_service__WEBPACK_IMPORTED_MODULE_3__.PostsService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: _app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.MenuController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_8__.DomSanitizer },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform }
];
CariPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-post',
        template: _cari_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_cari_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CariPage);



/***/ }),

/***/ 7249:
/*!************************************************!*\
  !*** ./src/app/cari/cari.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjYXJpLnBhZ2Uuc2NzcyJ9 */";

/***/ }),

/***/ 880:
/*!************************************************!*\
  !*** ./src/app/cari/cari.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-row>\n      <ion-menu-toggle>\n        <ion-button fill=\"clear\">\n          <ion-icon size=\"large\" name=\"menu-outline\"></ion-icon>\n        </ion-button>\n      </ion-menu-toggle>\n      <ion-title class=\"ion-text-justify\">Daftar Pencarian {{kw}}</ion-title>\n    </ion-row>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n    <ion-row wrap>\n      <ion-col size-lg=\"6\" size-md=\"12\" size-sm=\"12\" size-xs=\"12\" size=\"auto\" *ngFor=\"let post of itemListData\">     \n        <ion-card *ngIf=\"checkMobile == true;else elsemobile\" (click)=\"goToLink(post.permalink); addHistory(post.id_rss)\">\n          <ion-grid fixed>           \n            <ion-row>\n              <ion-col size=\"4\">\n                <img height=\"400\" width=\"600\" referrerpolicy=\"no-referrer\" attr=\"referrerpolicy:no-referrer\"\n                  [src]=\"showImage(post.thumb)\" class=\"img-thumb\" />\n              </ion-col>\n              <ion-col size=\"8\">\n                <ion-card-content>\n                  <ion-card-title style=\"text-align: center;padding-bottom: 5%;\">{{post.ft}}</ion-card-title>\n                  <ion-card-subtitle>{{post.title}}</ion-card-subtitle>\n                  <ion-text>\n                    <div class=\"ion-text-center\" style=\"padding-top:3%;\">\n                      {{post.timestamp * 1000 | date: 'dd MMMM yyyy'}}</div>\n                  </ion-text>\n                </ion-card-content>\n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </ion-card>\n\n        <ng-template #elsemobile>\n          <ion-card (click)=\"openDetailModal(post); addHistory(post.id_rss)\">\n            <ion-grid fixed>             \n              <ion-row>\n                <ion-col size=\"4\">\n                  <img height=\"400\" width=\"600\" referrerpolicy=\"no-referrer\" attr=\"referrerpolicy:no-referrer\"\n                    [src]=\"showImage(post.thumb)\" class=\"img-thumb\" />\n                </ion-col>\n                <ion-col size=\"8\">\n                  <ion-card-content>\n                    <ion-card-title style=\"text-align: center;padding-bottom: 5%;\">{{post.ft}}</ion-card-title>\n                    <ion-card-subtitle>{{post.title}}</ion-card-subtitle>\n                    <ion-text>\n                      <div class=\"ion-text-center\" style=\"padding-top:3%;\">\n                        {{post.timestamp * 1000 | date: 'dd MMMM yyyy'}}</div>\n                    </ion-text>\n                  </ion-card-content>\n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </ion-card>\n        </ng-template>\n\n      </ion-col>\n    </ion-row>\n  </ion-list>\n\n  <ion-infinite-scroll *ngIf=\"completed == false\" (ionInfinite)=\"doInfinite($event)\">\n    <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"Loading more data...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_cari_cari_module_ts.js.map